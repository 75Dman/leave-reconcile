# Leave Reconcile — Publish `docs/` to GitHub Pages

This repository contains a client-side web app in the `docs/` folder that can be hosted on GitHub Pages.

This README explains the simplest ways to publish the site and includes an optional GitHub Actions workflow snippet to deploy `docs/` automatically.

## Quick local preview

Run a static server from the project root and open http://localhost:8000:

```powershell
cd "C:\Users\Rande\Leave Reconcile\docs"
python -m http.server 8000
# Then open http://localhost:8000 in your browser
```

## Option A — GitHub Pages (serve `docs/` from `main` branch)

1. Commit and push your repository to GitHub (branch `main` / `master`).
2. In the repository on GitHub, go to Settings → Pages.
3. Under "Source" choose the branch (`main`) and the `/docs` folder as the root, then Save.
4. GitHub will publish the site at `https://<your-username>.github.io/<repo-name>/` (or a custom domain if you add a `CNAME` file).

This method requires no CI and is the simplest for a static `docs/` folder.

## Option B — Automated deploy with GitHub Actions (gh-pages branch)

If you prefer automatic deployments on push, use the `peaceiris/actions-gh-pages` action to publish `docs/` to the `gh-pages` branch.

Below is an example workflow you can add to `.github/workflows/deploy-gh-pages.yml` (optional):

```yaml
name: Deploy docs to GitHub Pages

on:
  push:
    branches:
      - main

jobs:
  deploy:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v4
      - name: Deploy to gh-pages
        uses: peaceiris/actions-gh-pages@v3
        with:
          github_token: ${{ secrets.GITHUB_TOKEN }}
          publish_dir: ./docs
```

Notes:
- This workflow publishes the `docs/` folder to the `gh-pages` branch on every push to `main`.
- Use Option A (Pages from `main`/`docs`) if you do not want a separate `gh-pages` branch.

## CNAME / custom domain

If you use a custom domain, add a `CNAME` file containing your domain into `docs/` (or the published branch's root). GitHub Pages will pick it up on publish.

## Next steps I can do for you

- Add the optional GitHub Actions workflow file (`.github/workflows/deploy-gh-pages.yml`).
- Create and push a commit with `README.md` (and the workflow) to your remote. I will ask for confirmation before pushing.

If you want me to add the workflow and commit/push the change, tell me which option you prefer (A — Pages from `docs/` on `main`, or B — Actions deploy to `gh-pages`).
